# WiFiNugget_Digi

Detailed project documentation.
