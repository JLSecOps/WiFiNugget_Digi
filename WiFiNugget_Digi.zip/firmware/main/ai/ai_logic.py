class AILogic:
    pass
