class XPManager:
    pass
