def define_tasks():
    return {}
