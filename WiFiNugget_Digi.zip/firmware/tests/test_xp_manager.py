import unittest

class TestXPManager(unittest.TestCase):
    pass
